import java.util.Scanner;

public class divide {

    public void divide() {

        Scanner input = new Scanner(System.in);


        System.out.print("welcome to divide");
        System.out.println("\n" + "please enter the two numbers you want to divide");

        int a = input.nextInt();
        int b = input.nextInt();

        int result = (a / b);

        System.out.println("result : " + result);
    }
}
