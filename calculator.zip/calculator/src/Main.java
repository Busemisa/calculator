import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        addition multi = new addition();

        factorial fac = new factorial();

        minus ext = new minus();

        divide div = new divide();

        modding mod = new modding();

        impact im = new impact();







        Scanner input = new Scanner(System.in);

        System.out.println("Welcome to calculator \n Operations performed on the calculator: \n 1)addition, \n 2)division, \n 3)impact, \n 4)minus, \n 5)mode taking, \n 6)factorial calculations are made");

        System.out.print("\n" + "Please select the action you want to perform : ");

        int select = input.nextInt();

        if(select==1){
            multi.addition();

        } else if (select==2) {
            div.divide();

        } else if (select==3) {
            im.multiply();

        } else if (select==4) {
            ext.minus();

        } else if (select==5) {
            mod.modding();

        } else if (select==6) {
            fac.factorial();

        }else {
            System.out.println("error");
        }




    }




}