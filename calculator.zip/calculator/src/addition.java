import java.util.Scanner;

public class addition {

    public void addition(){

        Scanner input = new Scanner(System.in);


        System.out.print("welcome to addition");
        System.out.println("\n" + "please enter the two numbers you want to add");

        int a = input.nextInt();
        int b = input.nextInt();

        int result = (a+b);

        System.out.println("result : " + result);





    }

}
