import java.util.Scanner;

public class minus {

    public void minus() {

        Scanner input = new Scanner(System.in);


        System.out.print("welcome to minus ");
        System.out.println("\n" + "please enter the two numbers you want to take away");

        int a = input.nextInt();
        int b = input.nextInt();

        int result = (a - b);

        System.out.println("result : " + result);
    }
}