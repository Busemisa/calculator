import java.util.Scanner;

public class impact {

    public void multiply() {

        Scanner input = new Scanner(System.in);


        System.out.print("welcome to multiply ");
        System.out.println("\n" + "please enter the two numbers you want to multiply");

        int a = input.nextInt();
        int b = input.nextInt();

        int result = (a * b);

        System.out.println("result : " + result);
    }
}
